import React, { useState, useEffect } from 'react';

interface SignUpProps {
  email?: string;
  onNext: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ email = '', onNext }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: email,
    password: '',
    inviteCode: ''
  });

  // Effect to simulate extracting invite code from URL if present
  // In a real app, we'd use useLocation from react-router
  useEffect(() => {
    // Check URL search params (mock logic)
    const urlParams = new URLSearchParams(window.location.search);
    const invite = urlParams.get('invite');
    if (invite) {
      setFormData(prev => ({ ...prev, inviteCode: invite }));
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 py-12">
      <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-gray-100">
        <h2 className="text-3xl font-black italic tracking-tight text-[#0D1C22] mb-2">Create Account</h2>
        <p className="text-gray-500 mb-8">Join the network for students and new grads.</p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          {/* Full Name */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
            <input
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="e.g. Jane Doe"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
              required
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">School Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@edu.com"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
              required
            />
          </div>

          {/* Invite Code */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Invite Code</label>
            <input
              type="text"
              name="inviteCode"
              value={formData.inviteCode}
              onChange={handleChange}
              placeholder="Enter code from your college"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
            />
            {formData.inviteCode && (
               <p className="text-xs text-green-600 font-semibold mt-2 flex items-center gap-1">
                 ✅ Invite code applied
               </p>
            )}
          </div>

          <button 
            type="submit" 
            className="mt-4 w-full bg-[#0D1C22] text-white font-bold py-4 rounded-xl text-lg hover:bg-gray-900 transition-colors shadow-lg shadow-gray-200"
          >
            Create Account
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-6">
          Already have an account? <a href="#" className="font-bold text-[#0D1C22] underline">Log in</a>
        </p>
      </div>
    </div>
  );
};

export default SignUp;