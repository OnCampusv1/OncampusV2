import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, ChevronDown, GraduationCap, Building2, School, Bell, MessageSquare, User } from 'lucide-react';

interface NavbarProps {
  onSignup?: () => void;
  onLogin?: () => void;
  onLogoClick?: () => void;
  hideAuthButtons?: boolean;
  isLoggedIn?: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ onSignup, onLogin, onLogoClick, hideAuthButtons = false, isLoggedIn = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <nav className="w-full px-4 md:px-8 py-4 flex items-center justify-between relative z-50 bg-[#FDFDF5] border-b border-gray-100">
      {/* Logo */}
      <div onClick={onLogoClick} className="flex items-center gap-3 cursor-pointer select-none">
        <div className="w-10 h-10 rounded-lg bg-[#0D1C22] flex items-center justify-center shrink-0">
             <svg width="24" height="24" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path 
                    d="M48.5 18C30.5 18 18 31.5 18 50C18 68.5 30.5 82 48.5 82C66.5 82 79 68.5 79 50C79 31.5 66.5 18 48.5 18ZM48.5 8C72 8 92 27 92 50C92 73 72 92 48.5 92C25 92 8 73 8 50C8 27 25 8 48.5 8Z" 
                    fill="#D7F037" 
                    transform="rotate(-10 50 50)"
                />
             </svg>
        </div>
        <span className="font-black text-2xl italic tracking-tight text-[#0D1C22]">OnCampus</span>
      </div>

      {/* Desktop Menu */}
      <div className="hidden md:flex items-center gap-6 text-sm font-semibold">
        
        {!isLoggedIn && (
          <div className="relative mr-2" ref={dropdownRef}>
            <button 
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-1 hover:text-gray-600 transition-colors py-2 text-[#0D1C22]"
            >
              Students <ChevronDown size={16} strokeWidth={2.5} className={`transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
            </button>
            
            {/* Dropdown Menu */}
            {dropdownOpen && (
              <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-gray-100 py-2 flex flex-col z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                <a href="#" className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 text-[#0D1C22] transition-colors group">
                  <GraduationCap size={20} strokeWidth={2} className="text-black" />
                  <span className="font-medium text-base">Students</span>
                </a>
                <a href="#" className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 text-[#0D1C22] transition-colors group">
                  <Building2 size={20} strokeWidth={2} className="text-black" />
                  <span className="font-medium text-base">Employers</span>
                </a>
                <a href="#" className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 text-[#0D1C22] transition-colors group">
                  <School size={20} strokeWidth={2} className="text-black" />
                  <span className="font-medium text-base">Universities</span>
                </a>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        {!isLoggedIn && !hideAuthButtons && (
          <>
            <button 
              onClick={onSignup}
              className="px-5 py-2.5 border border-black text-[#0D1C22] font-bold rounded-lg hover:bg-gray-50 transition-colors"
            >
              Sign up
            </button>
            <button 
              onClick={onLogin}
              className="px-5 py-2.5 bg-[#0D1C22] text-white font-bold rounded-lg hover:bg-opacity-90 transition-colors"
            >
              Log in
            </button>
          </>
        )}

        {isLoggedIn && (
           <div className="flex items-center gap-6">
              <button className="text-gray-500 hover:text-[#0D1C22] transition-colors">
                 <Bell size={24} />
              </button>
              <button className="text-gray-500 hover:text-[#0D1C22] transition-colors">
                 <MessageSquare size={24} />
              </button>
              <div className="flex items-center gap-2 pl-2 border-l border-gray-200">
                  <div className="w-10 h-10 rounded-full bg-[#D7F037] border-2 border-white shadow-sm flex items-center justify-center overflow-hidden">
                    <User size={20} className="text-[#0D1C22]" />
                  </div>
              </div>
           </div>
        )}
      </div>

      {/* Mobile Menu Toggle / Profile */}
      <div className="md:hidden">
         {isLoggedIn ? (
            <button onClick={() => setIsOpen(!isOpen)} className="relative outline-none">
              <div className="w-10 h-10 rounded-full bg-[#D7F037] border-2 border-white shadow-sm flex items-center justify-center overflow-hidden">
                 <User size={20} className="text-[#0D1C22]" />
              </div>
              {isOpen && (
                 <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 border border-gray-200">
                    <X size={12} className="text-black"/>
                 </div>
              )}
            </button>
         ) : (
            <button className="text-[#0D1C22]" onClick={() => setIsOpen(!isOpen)}>
               {isOpen ? <X /> : <Menu />}
            </button>
         )}
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 w-full bg-[#FDFDF5] shadow-lg flex flex-col p-6 gap-6 md:hidden border-b border-gray-200 z-40 animate-in slide-in-from-top-2 fade-in duration-200">
           {!isLoggedIn && (
             <div className="flex flex-col gap-4">
               <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Explore</span>
               <a href="#" className="flex items-center gap-3 text-lg font-bold text-[#0D1C22]">
                  <GraduationCap size={20} /> Students
               </a>
               <a href="#" className="flex items-center gap-3 text-lg font-bold text-[#0D1C22]">
                  <Building2 size={20} /> Employers
               </a>
               <a href="#" className="flex items-center gap-3 text-lg font-bold text-[#0D1C22]">
                  <School size={20} /> Universities
               </a>
             </div>
           )}
           {!isLoggedIn && !hideAuthButtons && (
             <div className="flex flex-col gap-3 pt-4 border-t border-gray-200">
               <button onClick={() => { onSignup?.(); setIsOpen(false); }} className="w-full py-3 border border-black rounded-lg font-bold text-[#0D1C22]">Sign up</button>
               <button onClick={() => { onLogin?.(); setIsOpen(false); }} className="w-full py-3 bg-[#0D1C22] text-white rounded-lg font-bold">Log in</button>
             </div>
           )}
           {isLoggedIn && (
              <div className="flex flex-col gap-4">
                 <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
                    <div className="w-12 h-12 rounded-full bg-[#D7F037] border-2 border-white shadow-sm flex items-center justify-center overflow-hidden">
                       <User size={24} className="text-[#0D1C22]" />
                    </div>
                    <div>
                       <p className="font-bold text-[#0D1C22]">Student Name</p>
                       <p className="text-sm text-gray-500">student@college.edu</p>
                    </div>
                 </div>
                 <a href="#" className="flex items-center gap-3 text-lg font-bold text-[#0D1C22]">
                    <Bell size={20} /> Notifications
                 </a>
                 <a href="#" className="flex items-center gap-3 text-lg font-bold text-[#0D1C22]">
                    <User size={20} /> Profile
                 </a>
                 <button onClick={() => { /* Add logout logic here */ setIsOpen(false); }} className="flex items-center gap-3 text-lg font-bold text-red-600 mt-2">
                    Log Out
                 </button>
              </div>
           )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;