import React, { useState } from 'react';
import { 
  Home, 
  Briefcase, 
  Calendar, 
  MessageCircle, 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  MoreHorizontal,
  ThumbsUp,
  Share2,
  Send,
  User,
  CheckCircle2,
  ArrowLeft,
  FileText,
  Edit2,
  Plus,
  UploadCloud,
  Image as ImageIcon,
  Video,
  X
} from 'lucide-react';

type Tab = 'feed' | 'jobs' | 'events' | 'inbox' | 'profile';

// --- MOCK DATA ---
const JOBS = [
  { id: 1, title: 'Product Design Intern', company: 'Spotify', location: 'New York, NY', type: 'Internship', posted: '2d ago', logo: 'bg-green-500 text-white', isCampus: false },
  { id: 2, title: 'Software Engineer (New Grad)', company: 'Airbnb', location: 'San Francisco, CA', type: 'Full-time', posted: '5h ago', logo: 'bg-red-500 text-white', isCampus: true },
  { id: 3, title: 'Marketing Associate', company: 'Nike', location: 'Remote', type: 'Full-time', posted: '1d ago', logo: 'bg-black text-white', isCampus: false },
  { id: 4, title: 'Data Scientist Intern', company: 'Netflix', location: 'Los Gatos, CA', type: 'Internship', posted: '3d ago', logo: 'bg-red-600 text-white', isCampus: true },
  { id: 5, title: 'Campus Ambassador', company: 'OnePlus', location: 'On Campus', type: 'Part-time', posted: '1w ago', logo: 'bg-red-600 text-white', isCampus: true },
];

const EVENTS = [
  { id: 1, title: 'Google Cloud Career Fair', company: 'Google', date: 'Oct 24', time: '2:00 PM', location: 'Virtual', logo: 'bg-blue-500 text-white' },
  { id: 2, title: 'Resume Workshop', company: 'University Career Center', date: 'Oct 26', time: '4:00 PM', location: 'Student Union', logo: 'bg-yellow-500 text-black' },
  { id: 3, title: 'Tech Talk: Future of AI', company: 'OpenAI', date: 'Nov 02', time: '11:00 AM', location: 'Auditorium A', logo: 'bg-green-600 text-white' },
];

const MESSAGES = [
  { id: 1, name: 'Sarah Wilson', role: 'Recruiter at Google', preview: 'Hi! I saw your profile and thought...', time: '10:30 AM', unread: true },
  { id: 2, name: 'Mike Chen', role: 'Alumni Mentor', preview: 'No problem, happy to help!', time: 'Yesterday', unread: false },
  { id: 3, name: 'Amazon Careers', role: 'Automated Message', preview: 'Application status update: In Review', time: 'Oct 20', unread: false },
];

const POSTS = [
  { id: 1, author: 'David Kim', role: 'Student at Stanford', content: 'Just accepted an offer at Google for next summer! 🚀 Huge thanks to the OnCampus community for the interview prep help.', likes: 142, comments: 23, time: '2h ago' },
  { id: 2, author: 'Microsoft Life', role: 'Company Page', content: 'We are opening applications for our 2025 Explorer Program. Tag a friend who should apply! 👇', likes: 856, comments: 120, time: '5h ago' },
];

const USER_PROFILE = {
  name: "Student Name",
  role: "Computer Science Student",
  college: "National Institute of Technology",
  batch: "Class of 2025",
  about: "Passionate about building scalable web applications and exploring AI. Currently looking for summer internships.",
  skills: ["React", "TypeScript", "Node.js", "Python", "UI/UX Design"],
  resume: "student_resume_v2.pdf",
  resumeDate: "Oct 12, 2024"
};

// --- SUB COMPONENTS ---

const JobCard: React.FC<{ job: any }> = ({ job }) => (
  <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex gap-4 group relative">
    {job.isCampus && (
      <div className="absolute top-4 right-4 bg-purple-100 text-purple-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wide">
        Campus Hire
      </div>
    )}
    <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg shrink-0 ${job.logo}`}>
      {job.company[0]}
    </div>
    <div className="flex-1">
      <div className="flex justify-between items-start pr-16">
         <h3 className="font-bold text-lg text-[#0D1C22] group-hover:underline">{job.title}</h3>
      </div>
      <p className="text-gray-600 font-medium">{job.company}</p>
      
      <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
         <span className="flex items-center gap-1"><MapPin size={14}/> {job.location}</span>
         <span className="flex items-center gap-1"><Clock size={14}/> {job.posted}</span>
         <span className="bg-gray-100 px-2 py-0.5 rounded text-xs font-semibold text-gray-700">{job.type}</span>
      </div>
    </div>
  </div>
);

const EventCard: React.FC<{ event: any }> = ({ event }) => (
  <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex gap-5 items-center">
    <div className="flex flex-col items-center justify-center w-16 h-16 bg-gray-50 rounded-xl border border-gray-200 shrink-0">
       <span className="text-xs font-bold text-gray-500 uppercase">{event.date.split(' ')[0]}</span>
       <span className="text-xl font-black text-[#0D1C22]">{event.date.split(' ')[1]}</span>
    </div>
    <div className="flex-1">
       <h3 className="font-bold text-lg text-[#0D1C22]">{event.title}</h3>
       <p className="text-gray-600">{event.company} • {event.time}</p>
       <p className="text-sm text-gray-400 flex items-center gap-1 mt-1"><MapPin size={12}/> {event.location}</p>
    </div>
    <button className="bg-white border border-[#0D1C22] text-[#0D1C22] px-4 py-2 rounded-lg font-bold hover:bg-[#0D1C22] hover:text-white transition-colors">
       Register
    </button>
  </div>
);

// --- VIEWS ---

const FeedView = ({ setTab }: { setTab: (t: Tab) => void }) => (
  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    {/* Welcome Header */}
    <div className="bg-[#D7F037] rounded-[2rem] p-8 md:p-10 relative overflow-hidden">
        <div className="relative z-10 max-w-lg">
           <h1 className="text-4xl md:text-5xl font-black italic tracking-tight text-[#0D1C22] mb-4">Good Morning, Student!</h1>
           <p className="text-[#0D1C22] font-medium text-lg mb-6">You have 3 new job matches and 1 upcoming event today.</p>
           <button onClick={() => setTab('jobs')} className="bg-[#0D1C22] text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-800 transition-colors">
              View Matches
           </button>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none">
           <svg width="300" height="300" viewBox="0 0 100 100" fill="currentColor">
              <path d="M48.5 18C30.5 18 18 31.5 18 50C18 68.5 30.5 82 48.5 82C66.5 82 79 68.5 79 50C79 31.5 66.5 18 48.5 18ZM48.5 8C72 8 92 27 92 50C92 73 72 92 48.5 92C25 92 8 73 8 50C8 27 25 8 48.5 8Z"/>
           </svg>
        </div>
    </div>

    {/* Create Post */}
    <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
      <div className="flex gap-3 mb-3">
        <div className="w-10 h-10 rounded-full bg-[#D7F037] border border-gray-100 flex items-center justify-center shrink-0">
          <User size={20} className="text-[#0D1C22]" />
        </div>
        <input 
          type="text" 
          placeholder="Share an update, question, or achievement..." 
          className="flex-1 bg-gray-50 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
        />
      </div>
      <div className="flex justify-between items-center px-2">
        <div className="flex gap-4">
          <button className="flex items-center gap-2 text-gray-500 hover:text-[#0D1C22] text-sm font-medium">
            <ImageIcon size={18} /> Photo
          </button>
          <button className="flex items-center gap-2 text-gray-500 hover:text-[#0D1C22] text-sm font-medium">
            <Video size={18} /> Video
          </button>
        </div>
        <button className="bg-[#0D1C22] text-white px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-opacity-90">
          Post
        </button>
      </div>
    </div>

    {/* Feed Posts */}
    <section>
      <h2 className="text-xl font-bold text-[#0D1C22] mb-4 px-2">Latest from your network</h2>
      <div className="space-y-4">
         {POSTS.map(post => (
            <div key={post.id} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
               <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                     <User size={20} className="text-gray-500" />
                  </div>
                  <div>
                     <h4 className="font-bold text-[#0D1C22]">{post.author}</h4>
                     <p className="text-xs text-gray-500">{post.role} • {post.time}</p>
                  </div>
               </div>
               <p className="text-gray-800 mb-4 leading-relaxed">{post.content}</p>
               <div className="flex gap-6 text-gray-500 text-sm font-medium border-t border-gray-50 pt-4">
                  <button className="flex items-center gap-2 hover:text-blue-600"><ThumbsUp size={16}/> {post.likes}</button>
                  <button className="flex items-center gap-2 hover:text-blue-600"><MessageCircle size={16}/> {post.comments}</button>
                  <button className="flex items-center gap-2 hover:text-blue-600"><Share2 size={16}/> Share</button>
               </div>
            </div>
         ))}
      </div>
    </section>
  </div>
);

const JobsView = () => {
  const [filter, setFilter] = useState<'all' | 'campus'>('all');

  const filteredJobs = JOBS.filter(job => filter === 'all' ? true : job.isCampus);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm sticky top-0 z-20">
         <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
               <input type="text" placeholder="Search jobs..." className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-lg outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all" />
            </div>
            <button className="px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50 text-[#0D1C22]"><Filter size={20}/></button>
         </div>

         {/* Job Type Toggle */}
         <div className="flex bg-gray-100 p-1 rounded-lg relative">
            <div 
              className={`absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-md shadow-sm transition-all duration-300 ${filter === 'campus' ? 'translate-x-[calc(100%+8px)]' : 'translate-x-0'}`}
            ></div>
            <button 
              onClick={() => setFilter('all')}
              className={`flex-1 py-2 text-sm font-bold text-center relative z-10 transition-colors ${filter === 'all' ? 'text-[#0D1C22]' : 'text-gray-500'}`}
            >
              All Jobs
            </button>
            <button 
              onClick={() => setFilter('campus')}
              className={`flex-1 py-2 text-sm font-bold text-center relative z-10 transition-colors ${filter === 'campus' ? 'text-[#0D1C22]' : 'text-gray-500'}`}
            >
              Campus Hires
            </button>
         </div>
      </div>
      
      <div className="space-y-4">
         {filteredJobs.length > 0 ? (
           filteredJobs.map(job => <JobCard key={job.id} job={job} />)
         ) : (
           <div className="text-center py-20 text-gray-400">
             <Briefcase size={48} className="mx-auto mb-4 opacity-20" />
             <p>No jobs found in this category.</p>
           </div>
         )}
      </div>
    </div>
  );
};

const EventsView = () => (
   <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-end mb-6">
         <div>
            <h2 className="text-3xl font-black italic tracking-tight text-[#0D1C22]">Events</h2>
            <p className="text-gray-500">Discover career fairs, workshops, and tech talks.</p>
         </div>
         <select className="bg-white border border-gray-200 px-4 py-2 rounded-lg font-medium outline-none">
            <option>This Week</option>
            <option>This Month</option>
         </select>
      </div>
      <div className="space-y-4">
         {EVENTS.map(event => <EventCard key={event.id} event={event} />)}
         <div className="py-2 text-sm font-bold text-gray-400 uppercase tracking-widest mt-8 mb-4">Past Events</div>
         <div className="opacity-60 grayscale hover:grayscale-0 transition-all duration-300">
             <EventCard event={{...EVENTS[0], title: "Meta Recruiting Session", date: "Sep 12", time: "Ended"}} />
         </div>
      </div>
   </div>
);

const InboxView = () => {
  const [selectedChat, setSelectedChat] = useState<number | null>(null);
  const activeMessage = MESSAGES.find(m => m.id === selectedChat) || MESSAGES[0];

  return (
    <div className="h-[calc(100vh-200px)] md:h-[calc(100vh-140px)] bg-white rounded-2xl border border-gray-100 shadow-sm flex overflow-hidden animate-in fade-in duration-500">
       <div className={`w-full md:w-1/3 border-r border-gray-100 flex-col md:flex ${selectedChat !== null ? 'hidden' : 'flex'}`}>
          <div className="p-4 border-b border-gray-100">
             <h3 className="font-bold text-lg text-[#0D1C22]">Messages</h3>
          </div>
          <div className="flex-1 overflow-y-auto">
             {MESSAGES.map(msg => (
                <div 
                   key={msg.id} 
                   onClick={() => setSelectedChat(msg.id)}
                   className={`p-4 border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors ${selectedChat === msg.id ? 'bg-blue-50/50' : ''}`}
                >
                   <div className="flex justify-between mb-1">
                      <span className={`font-bold text-sm truncate ${msg.unread ? 'text-[#0D1C22]' : 'text-gray-600'}`}>{msg.name}</span>
                      <span className="text-xs text-gray-400">{msg.time}</span>
                   </div>
                   <p className="text-xs text-gray-500 mb-1">{msg.role}</p>
                   <p className={`text-sm truncate ${msg.unread ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>{msg.preview}</p>
                </div>
             ))}
          </div>
       </div>
       <div className={`flex-1 flex-col bg-gray-50/50 md:flex ${selectedChat === null ? 'hidden' : 'flex'}`}>
          <div className="p-4 bg-white border-b border-gray-100 flex justify-between items-center">
             <div className="flex items-center gap-3">
                <button onClick={() => setSelectedChat(null)} className="md:hidden text-gray-500 hover:text-[#0D1C22]">
                   <ArrowLeft size={20} />
                </button>
                <div>
                   <h3 className="font-bold text-[#0D1C22]">{activeMessage.name}</h3>
                   <p className="text-xs text-gray-500">{activeMessage.role}</p>
                </div>
             </div>
             <button className="text-gray-400 hover:text-[#0D1C22]"><MoreHorizontal size={20}/></button>
          </div>
          <div className="flex-1 p-6 space-y-6 overflow-y-auto">
             <div className="flex flex-col gap-1 items-start max-w-[85%] md:max-w-[80%]">
                <div className="bg-white border border-gray-200 p-4 rounded-2xl rounded-tl-none text-sm text-gray-800 shadow-sm">
                   Hi! I saw your profile and thought your experience with React would be a great fit for our summer internship program. Would you be open to a quick chat?
                </div>
                <span className="text-xs text-gray-400 ml-2">10:30 AM</span>
             </div>
             <div className="flex flex-col gap-1 items-end max-w-[85%] md:max-w-[80%] self-end">
                <div className="bg-[#0D1C22] text-white p-4 rounded-2xl rounded-tr-none text-sm shadow-sm">
                   Hi Sarah! Thanks for reaching out. I'd love to learn more about the opportunity. When are you available?
                </div>
                <span className="text-xs text-gray-400 mr-2">10:35 AM <CheckCircle2 size={10} className="inline ml-1"/></span>
             </div>
          </div>
          <div className="p-4 bg-white border-t border-gray-100">
             <div className="flex gap-2">
                <input type="text" placeholder="Type a message..." className="flex-1 bg-gray-100 rounded-full px-6 py-3 outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all text-sm" />
                <button className="w-12 h-12 bg-[#D7F037] rounded-full flex items-center justify-center text-[#0D1C22] hover:bg-[#c5dc33] transition-colors shadow-sm">
                   <Send size={20} className="ml-0.5" />
                </button>
             </div>
          </div>
       </div>
    </div>
  );
};

const ProfileView = () => (
  <div className="space-y-6 animate-in fade-in duration-500">
    {/* Profile Header Card */}
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="h-32 bg-gradient-to-r from-[#0D1C22] to-gray-800 relative">
        <button className="absolute bottom-4 right-4 bg-black/30 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-medium border border-white/20 hover:bg-black/50 transition-colors flex items-center gap-1">
          <ImageIcon size={12} /> Edit Cover
        </button>
      </div>
      <div className="px-6 pb-6 relative">
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-end -mt-12 mb-4">
          <div className="w-24 h-24 rounded-full bg-[#D7F037] border-4 border-white shadow-md flex items-center justify-center overflow-hidden shrink-0">
             <User size={40} className="text-[#0D1C22]" />
          </div>
          <div className="flex-1 mt-2 md:mt-0">
            <h1 className="text-2xl font-black text-[#0D1C22]">{USER_PROFILE.name}</h1>
            <p className="text-gray-600 font-medium">{USER_PROFILE.role}</p>
            <p className="text-sm text-gray-400">{USER_PROFILE.college} • {USER_PROFILE.batch}</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-bold text-[#0D1C22] hover:bg-gray-50 transition-colors mt-4 md:mt-0 w-full md:w-auto justify-center">
            <Edit2 size={16} /> Edit Profile
          </button>
        </div>
        <div className="prose prose-sm max-w-none text-gray-600">
          <p>{USER_PROFILE.about}</p>
        </div>
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Left Column */}
      <div className="space-y-6 md:col-span-2">
        {/* Resume Section */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
           <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg text-[#0D1C22]">Resume</h3>
              <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full flex items-center gap-1">
                <CheckCircle2 size={12} /> Synced
              </span>
           </div>
           
           <div className="border border-gray-200 rounded-xl p-4 flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-red-50 text-red-500 rounded-lg flex items-center justify-center shrink-0">
                 <FileText size={20} />
              </div>
              <div className="flex-1 overflow-hidden">
                 <p className="font-bold text-sm truncate">{USER_PROFILE.resume}</p>
                 <p className="text-xs text-gray-500">Updated {USER_PROFILE.resumeDate}</p>
              </div>
              <button className="text-gray-400 hover:text-[#0D1C22]">
                 <MoreHorizontal size={20} />
              </button>
           </div>
           
           <div className="flex items-center gap-2 p-3 bg-blue-50 text-blue-700 rounded-lg text-xs font-medium">
              <UploadCloud size={16} />
              <span>Details below are auto-filled from your resume. Upload a new one to update.</span>
           </div>

           <button className="w-full mt-4 py-3 border border-dashed border-gray-300 rounded-xl text-gray-500 font-bold hover:border-[#0D1C22] hover:text-[#0D1C22] transition-colors flex items-center justify-center gap-2">
             <UploadCloud size={20} /> Upload New Resume
           </button>
        </div>

        {/* Experience / Projects Placeholder */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
           <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg text-[#0D1C22]">Experience & Projects</h3>
              <button className="text-[#0D1C22] hover:bg-gray-50 p-2 rounded-full"><Plus size={20} /></button>
           </div>
           <div className="text-center py-8 text-gray-400">
              <p>Add your internships and projects here.</p>
           </div>
        </div>
      </div>

      {/* Right Column */}
      <div className="space-y-6">
        {/* Skills */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg text-[#0D1C22]">Skills</h3>
              <button className="text-[#0D1C22]"><Plus size={20} /></button>
           </div>
           <div className="flex flex-wrap gap-2">
              {USER_PROFILE.skills.map(skill => (
                <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-semibold">
                  {skill}
                </span>
              ))}
           </div>
        </div>

        {/* Academic Details */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
           <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg text-[#0D1C22]">Education</h3>
              <button className="text-gray-400 hover:text-[#0D1C22]"><Edit2 size={16} /></button>
           </div>
           <div className="space-y-4">
              <div>
                 <p className="text-xs text-gray-500 uppercase font-bold tracking-wide">Course</p>
                 <p className="font-semibold text-[#0D1C22]">B.Tech Computer Science</p>
              </div>
              <div>
                 <p className="text-xs text-gray-500 uppercase font-bold tracking-wide">Institution</p>
                 <p className="font-semibold text-[#0D1C22]">National Institute of Technology</p>
              </div>
              <div>
                 <p className="text-xs text-gray-500 uppercase font-bold tracking-wide">Year</p>
                 <p className="font-semibold text-[#0D1C22]">Final Year (2025)</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  </div>
);

// --- MAIN DASHBOARD COMPONENT ---

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('feed');

  // Desktop Nav Item
  const NavItem = ({ tab, icon: Icon, label }: { tab: Tab, icon: any, label: string }) => (
    <button 
      onClick={() => setActiveTab(tab)}
      className={`w-full flex items-center gap-4 px-6 py-4 rounded-xl transition-all duration-200 group ${activeTab === tab ? 'bg-[#0D1C22] text-white shadow-lg' : 'text-gray-500 hover:bg-white hover:text-[#0D1C22]'}`}
    >
      <Icon size={24} strokeWidth={activeTab === tab ? 2.5 : 2} className="shrink-0" />
      <span className="font-bold text-lg hidden md:block">{label}</span>
      {activeTab === tab && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#D7F037] hidden md:block"></div>}
    </button>
  );

  // Mobile Nav Item
  const MobileNavItem = ({ tab, icon: Icon, label }: { tab: Tab, icon: any, label: string }) => (
     <button 
        onClick={() => setActiveTab(tab)} 
        className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-colors ${activeTab === tab ? 'text-[#0D1C22]' : 'text-gray-400 hover:text-gray-600'}`}
     >
        <div className={`p-1 rounded-xl transition-all ${activeTab === tab ? 'bg-gray-100' : ''}`}>
           <Icon size={24} strokeWidth={activeTab === tab ? 2.5 : 2} />
        </div>
        <span className="text-[10px] font-bold">{label}</span>
     </button>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-4 md:py-8">
       <div className="flex flex-col md:flex-row gap-8">
          
          {/* Desktop Sidebar Navigation - Hidden on Mobile */}
          <aside className="hidden md:block w-64 shrink-0">
             <nav className="sticky top-24 space-y-2 bg-gray-50/50 p-2 rounded-2xl">
                <NavItem tab="feed" icon={Home} label="Home" />
                <NavItem tab="jobs" icon={Briefcase} label="Jobs" />
                <NavItem tab="events" icon={Calendar} label="Events" />
                <NavItem tab="inbox" icon={MessageCircle} label="Inbox" />
                <NavItem tab="profile" icon={User} label="Profile" />
             </nav>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1 min-w-0 pb-20 md:pb-0">
             {activeTab === 'feed' && <FeedView setTab={setActiveTab} />}
             {activeTab === 'jobs' && <JobsView />}
             {activeTab === 'events' && <EventsView />}
             {activeTab === 'inbox' && <InboxView />}
             {activeTab === 'profile' && <ProfileView />}
          </main>

       </div>

       {/* Mobile Bottom Navigation - Hidden on Desktop */}
       <div className="md:hidden fixed bottom-0 left-0 w-full bg-white/95 backdrop-blur-lg border-t border-gray-200 z-50 pb-safe">
          <nav className="flex justify-around items-center h-16 px-2">
            <MobileNavItem tab="feed" icon={Home} label="Home" />
            <MobileNavItem tab="jobs" icon={Briefcase} label="Jobs" />
            <MobileNavItem tab="events" icon={Calendar} label="Events" />
            <MobileNavItem tab="inbox" icon={MessageCircle} label="Inbox" />
            <MobileNavItem tab="profile" icon={User} label="Profile" />
          </nav>
       </div>
    </div>
  );
};

export default Dashboard;