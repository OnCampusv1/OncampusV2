import React from 'react';

interface FooterProps {
  isDarkMode?: boolean;
}

const Footer: React.FC<FooterProps> = ({ isDarkMode = false }) => {
  return (
    <footer className={`py-32 px-4 md:px-12 text-center md:text-left transition-colors duration-700`}>
      <div className="max-w-7xl mx-auto">
        <h2 className={`text-6xl md:text-8xl font-black leading-[0.9] tracking-tighter mb-12 transition-colors duration-700 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          START<br />
          BUILDING<br />
          YOUR CAREER
        </h2>
        
        <div className={`flex flex-col md:flex-row gap-8 justify-between items-start md:items-end border-t pt-12 transition-colors duration-700 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}>
           <div className={`flex gap-6 text-sm font-medium transition-colors duration-700 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
             <a href="#" className={`hover:${isDarkMode ? 'text-white' : 'text-black'} transition-colors`}>Terms</a>
             <a href="#" className={`hover:${isDarkMode ? 'text-white' : 'text-black'} transition-colors`}>Privacy</a>
             <a href="#" className={`hover:${isDarkMode ? 'text-white' : 'text-black'} transition-colors`}>Cookies</a>
           </div>
           
           <div className={`text-sm transition-colors duration-700 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
             © 2024 OnCampus Inc.
           </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;