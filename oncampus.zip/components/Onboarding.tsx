import React, { useState } from 'react';
import { Upload, FileText, Link as LinkIcon, ChevronRight, ArrowLeft } from 'lucide-react';

interface OnboardingProps {
  onComplete: () => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [academicData, setAcademicData] = useState({
    degree: '',
    branch: '',
    gradYear: ''
  });
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [resumeLink, setResumeLink] = useState('');

  const handleAcademicChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setAcademicData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setResumeFile(e.target.files[0]);
    }
  };

  const nextStep = () => setStep(2);
  const prevStep = () => setStep(1);

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-12">
      <div className="bg-white rounded-[2rem] p-8 md:p-12 shadow-xl border border-gray-100">
        
        {/* Progress Bar */}
        <div className="flex gap-2 mb-8">
           <div className={`h-1.5 flex-1 rounded-full transition-colors ${step >= 1 ? 'bg-[#0D1C22]' : 'bg-gray-200'}`}></div>
           <div className={`h-1.5 flex-1 rounded-full transition-colors ${step >= 2 ? 'bg-[#0D1C22]' : 'bg-gray-200'}`}></div>
        </div>

        {step === 1 && (
          <div className="animate-in slide-in-from-right-4 fade-in duration-300">
            <div className="mb-8 text-center">
                <h2 className="text-3xl font-black italic tracking-tight text-[#0D1C22] mb-3">Academic Details</h2>
                <p className="text-gray-500">Tell us what you're studying.</p>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Course / Degree</label>
                <input
                  type="text"
                  name="degree"
                  value={academicData.degree}
                  onChange={handleAcademicChange}
                  placeholder="e.g. B.Tech, MBA, B.Sc"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Branch / Specialization</label>
                <input
                  type="text"
                  name="branch"
                  value={academicData.branch}
                  onChange={handleAcademicChange}
                  placeholder="e.g. Computer Science, Marketing"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Graduation Year</label>
                <select
                  name="gradYear"
                  value={academicData.gradYear}
                  onChange={handleAcademicChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all appearance-none cursor-pointer"
                >
                  <option value="" disabled>Select Year</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                </select>
              </div>

              <button 
                onClick={nextStep}
                disabled={!academicData.degree || !academicData.branch || !academicData.gradYear}
                className="w-full bg-[#0D1C22] text-white font-bold py-4 rounded-xl text-lg hover:bg-gray-900 transition-colors shadow-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-4"
              >
                Next Step <ChevronRight size={20} />
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="animate-in slide-in-from-right-4 fade-in duration-300">
             <div className="mb-8 text-center relative">
                <button onClick={prevStep} className="absolute left-0 top-1 p-2 rounded-full hover:bg-gray-100 text-[#0D1C22]">
                  <ArrowLeft size={20} />
                </button>
                <h2 className="text-3xl font-black italic tracking-tight text-[#0D1C22] mb-3">Add Resume</h2>
                <p className="text-gray-500">Upload your CV to get matched with jobs.</p>
            </div>

            <div className="space-y-8">
              {/* File Upload Area */}
              <div className="relative border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:border-[#0D1C22] hover:bg-gray-50 transition-colors group">
                <input 
                  type="file" 
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="flex flex-col items-center gap-3">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center ${resumeFile ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400 group-hover:bg-[#0D1C22] group-hover:text-white transition-colors'}`}>
                    {resumeFile ? <FileText size={32} /> : <Upload size={32} />}
                  </div>
                  <div>
                    <p className="font-bold text-[#0D1C22] text-lg">
                      {resumeFile ? resumeFile.name : "Click to upload or drag and drop"}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">
                      {resumeFile ? "Resume selected" : "PDF, DOCX up to 10MB"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-gray-200"></div>
                <span className="flex-shrink-0 mx-4 text-gray-400 text-sm font-medium">OR ADD LINK</span>
                <div className="flex-grow border-t border-gray-200"></div>
              </div>

              {/* Link Input */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Resume Link</label>
                <div className="relative">
                  <LinkIcon size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="url"
                    value={resumeLink}
                    onChange={(e) => setResumeLink(e.target.value)}
                    placeholder="Google Drive, LinkedIn, Portfolio..."
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D1C22] transition-all"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-3 mt-6">
                <button 
                    onClick={onComplete}
                    className="w-full bg-[#D7F037] text-[#0D1C22] font-bold py-4 rounded-xl text-lg hover:bg-[#c5dc33] transition-colors shadow-lg"
                >
                    Complete Profile
                </button>
                 <button 
                    onClick={onComplete}
                    className="w-full bg-transparent text-gray-500 font-semibold py-2 rounded-xl hover:text-gray-800 text-sm"
                >
                    Skip for now
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Onboarding;